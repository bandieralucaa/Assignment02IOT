package main;


public interface EasyControllerObserver {

    void notifySolvedProblem();

}
